import sqlite3
from django.conf import settings
import os


DB_PATH = os.path.join(settings.BASE_DIR, 'BD.db')

def fetch_games_by_column(column_name: str, value: int) -> list:
    """Получение игр по указанному столбцу и значению."""
    try:
        # Подключаемся к базе данных
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # Формируем SQL-запрос для поиска игр
        query = f"SELECT Name_game FROM Games WHERE {column_name} = ?"
        cursor.execute(query, (value,))
        games = cursor.fetchall()
        conn.close()
        return [game[0] for game in games]  # Возвращаем список названий игр
    except sqlite3.Error as e:
        print(f"Ошибка работы с БД: {e}")
        return []

def get_random_game() -> str:
    """Получение случайной игры из базы данных."""
    try:
        # Подключаемся к базе данных
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # Выбираем случайную игру
        cursor.execute("SELECT Name_game FROM Games ORDER BY RANDOM() LIMIT 1")
        game = cursor.fetchone()
        conn.close()
        return game[0] if game else "Не удалось найти игру"
    except sqlite3.Error as e:
        print(f"Ошибка работы с БД: {e}")
        return "Ошибка при получении игры"

def count_games() -> int:
    """Подсчет общего количества игр в базе."""
    try:
        # Подключаемся к базе данных
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # Считаем количество игр
        cursor.execute("SELECT COUNT(*) FROM Games")
        count = cursor.fetchone()[0]
        conn.close()
        return count
    except sqlite3.Error as e:
        print(f"Ошибка работы с БД: {e}")
        return 0

def add_game_to_db(game_data: dict) -> str:
    try:
        name = game_data['name']
        genre = game_data['genre']
        developer = game_data['developer']
        publisher = game_data['publisher']
        tags = game_data['tags']
        localization = game_data['localization']

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        cursor.execute("SELECT id FROM Games WHERE Name_game = ?", (name.))
        if cursor.fetchhome():
            conn.close()
            return "Эта игра уже есть в базе данных!"
        if not context.args:
        await update.message.reply_text(
            "Пожалуйста, укажите данные игры в формате:\n"
            "/add Название игры; Жанр; Разработчик; Издатель; Самый популярный тег; Локализация\n\n"
            "Пример:\n"
            "/add The Witcher 3; RPG; CD Projekt; CD Projekt RED; Открытый мир; Полная"
        )
        return
    
    try:
        # Разбиваем ввод пользователя на компоненты
        data = ' '.join(context.args).split(';')
        if len(data) != 4:
            raise ValueError("Неверный формат данных")
            
        name, genre, developer, publisher, localization = [x.strip() for x in data]
        
        # Подключаемся к базе данных
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # Проверяем, существует ли игра
        cursor.execute("SELECT id FROM Games WHERE Name_game = ?", (name,))
        if cursor.fetchone():
            await update.message.reply_text("Эта игра уже есть в базе данных!")
            conn.close()
            return
            
        # Получаем или добавляем жанр
        cursor.execute("SELECT id FROM Genres WHERE Name = ?", (genre,))
        genre_id = cursor.fetchone()
        if not genre_id:
            cursor.execute("INSERT INTO Genres (Name) VALUES (?)", (genre,))
            genre_id = cursor.lastrowid
        else:
            genre_id = genre_id[0]
            
        # Получаем или добавляем разработчика
        cursor.execute("SELECT id FROM Developers WHERE Name = ?", (developer,))
        developer_id = cursor.fetchone()
        if not developer_id:
            cursor.execute("INSERT INTO Developers (Name) VALUES (?)", (developer,))
            developer_id = cursor.lastrowid
        else:
            developer_id = developer_id[0]
            
        # Получаем или добавляем издателя
        cursor.execute("SELECT id FROM Publishers WHERE Name = ?", (publisher,))
        publisher_id = cursor.fetchone()
        if not publisher_id:
            cursor.execute("INSERT INTO Publishers (Name) VALUES (?)", (publisher,))
            publisher_id = cursor.lastrowid
        else:
            publisher_id = publisher_id[0]

        # Получаем или добавляем тег
        cursor.execute("SELECT id FROM Tags WHERE Name = ?", (tags,))
        tags_id = cursor.fetchone()
        if not tags_id:
            cursor.execute("INSERT INTO Tags (Name) VALUES (?)", (tags,))
            tags_id = cursor.lastrowid
        else:
            tags_id = tags_id[0]

        # Получаем или добавляем локализацию
        cursor.execute("SELECT id FROM Localization WHERE Name = ?", (localization,))
        localization_id = cursor.fetchone()
        if not localization_id:
            cursor.execute("INSERT INTO Localization (Name) VALUES (?)", (localization,))
            localization_id = cursor.lastrowid
        else:
            localization_id = localization_id[0]
            
        # Добавляем игру в базу данных
        cursor.execute(
            "INSERT INTO Games (Name_game, id_Genre, id_Developer, id_Publisher, id_Tags, id_Localization) VALUES (?, ?, ?, ?)",
            (name, genre_id, developer_id, publisher_id, tags_id, localization_id)
        )

        conn.commit()
        conn.close()
        return f"Игра '{name}' успешно добавлена в базу данных!"

    except Exception as e:
        return f"Ошибка: {str(e)}"
