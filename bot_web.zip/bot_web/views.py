from django.shortcuts import render
from django http import JsonResponse
from django.views.decoration.csrf import csrf_exempt
import json
from core import *

def index(request):
    return render(request, 'bot_web/index.html')

@carf_exempt
def handle_message(request):
    if request.method == "POSt":
        try:
            data = json.loads(request.body)
            message_type = data.get('type')
            value = data.get('value')

            response_data = {}

            if message_type == "random_game":
                game = get_random_game()
                response_data = {'response': f"Случайная игра: {game}"}
                
