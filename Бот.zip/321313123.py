import sqlite3
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, MessageHandler, filters

# Конфигурация
DB_PATH = "BD.db"
BOT_TOKEN = "7488590281:AAEaitj-N8v6a8exda56z7RDhS4qoPXldQ0"

def fetch_games_by_column(column_name: str, value: int) -> list:
    """Получение игр по указанному столбцу и значению."""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        query = f"""
            SELECT Name_game 
            FROM Games 
            WHERE {column_name} = ?
        """
        cursor.execute(query, (value,))
        games = cursor.fetchall()
        conn.close()
        return [game[0] for game in games]
    except sqlite3.Error as e:
        print(f"Ошибка работы с БД: {e}")
        return []

async def start(update: Update, context):
    """Обработчик команды /start."""
    keyboard = [
        [InlineKeyboardButton("По жанру", callback_data='genre')],
        [InlineKeyboardButton("По разработчику", callback_data='developer')],
        [InlineKeyboardButton("По издателю", callback_data='publisher')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Выберите категорию для сортировки:", reply_markup=reply_markup)

async def handle_query(update: Update, context):
    """Обработчик выбора категории."""
    query = update.callback_query
    await query.answer()

    if query.data == 'genre':
        await query.edit_message_text("Введите ID жанра для поиска игр:")
        context.user_data['filter'] = 'id_Genre'
    elif query.data == 'developer':
        await query.edit_message_text("Введите ID разработчика для поиска игр:")
        context.user_data['filter'] = 'id_Developer'
    elif query.data == 'publisher':
        await query.edit_message_text("Введите ID издателя для поиска игр:")
        context.user_data['filter'] = 'id_Publisher'

async def filter_games(update: Update, context):
    """Обработчик текстового ввода для фильтрации."""
    column_name = context.user_data.get('filter')
    
    if not column_name:
        await update.message.reply_text("Пожалуйста, выберите категорию с помощью команды /start.")
        return

    try:
        value = int(update.message.text)
        games = fetch_games_by_column(column_name, value)
        
        if games:
            result = "\n".join(games)
            await update.message.reply_text(f"Найденные игры:\n{result}")
        else:
            await update.message.reply_text("Игры по вашему запросу не найдены.")
            
    except ValueError:
        await update.message.reply_text("Введите корректный ID (число).")
    except Exception as e:
        await update.message.reply_text("Произошла ошибка. Попробуйте позже.")
        print(f"Ошибка обработки запроса: {e}")

def main():
    """Основная функция запуска бота."""
    application = ApplicationBuilder().token(BOT_TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(handle_query))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, filter_games))
    
    application.run_polling()

if __name__ == "__main__":
    main()
